<lore>
未使用的条目
</lore>
<no_lore>
Placeholder
</no_lore>
<chapter name="信息"/>
Placeholder
<recipes_usages stack="buildcraftcore:volume_box"/>
Placeholder